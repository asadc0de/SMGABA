import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { P as Calendar, _ as Mail, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/resources-Dy_ZDJxy.js
var import_jsx_runtime = require_jsx_runtime();
var ARTICLES = [
	{
		title: "Mastering Restaurant Prime Costs: How to Stay Below the 60% Benchmark",
		category: "Hospitality Strategy",
		date: "August 2026",
		summary: "A step-by-step breakdown of managing COGS and labor costs in high-volume dining establishments to protect bottom-line operating margins.",
		readTime: "5 min read"
	},
	{
		title: "Maximizing the FICA Tip Tax Credit (Section 45B) for Food & Beverage Operators",
		category: "Tax Planning",
		date: "July 2026",
		summary: "Are you leaving substantial tax credits on the table? Learn how to calculate and claim your employer FICA tip credits accurately.",
		readTime: "4 min read"
	},
	{
		title: "13-Week Cash Flow Forecasting: The Executive CFO's Secret Weapon",
		category: "Financial Advisory",
		date: "June 2026",
		summary: "Why standard monthly budgets fail during growth phases, and how rolling 13-week forecasts give business owners unprecedented runway clarity.",
		readTime: "6 min read"
	},
	{
		title: "Real Estate 1031 Exchange Timelines & Entity Structuring Guidelines",
		category: "Real Estate",
		date: "May 2026",
		summary: "Key rules and deadlines property investors must follow to defer capital gains and maintain pristine capital accounts across partnerships.",
		readTime: "7 min read"
	}
];
function ResourcesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "SMG Insights & Updates",
					title: "Resources & Newsletters",
					description: "Discover practical strategies, legislative updates, and executive financial frameworks to help your business thrive.",
					buttonText: "SUBSCRIBE",
					buttonHref: "#newsletter"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-b border-border/80 bg-navy text-white py-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid items-center gap-8 lg:grid-cols-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-blue-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "SMG Executive Briefing" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 font-serif-hero text-2xl sm:text-3xl font-bold text-white",
										children: "Get Industry Insights Delivered Monthly"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-slate-200 sm:text-base",
										children: "Join hundreds of restaurateurs, developers, and business owners who receive our curated hospitality and tax analysis."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: (e) => {
										e.preventDefault();
										alert("Thank you for subscribing to the SMG Newsletter!");
									},
									className: "flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										required: true,
										placeholder: "Enter your email",
										className: "h-12 w-full rounded-full border border-white/20 bg-white/10 px-5 text-sm text-white placeholder:text-white/60 focus:border-white focus:outline-none"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										size: "lg",
										className: "shrink-0 bg-white text-navy hover:bg-slate-100",
										children: "Subscribe"
									})]
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-8 sm:grid-cols-2",
							children: ARTICLES.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-surface flex flex-col justify-between p-8 transition-all hover:-translate-y-1 hover:shadow-xl sm:p-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2 text-xs font-semibold text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-navy/10 px-3 py-1 font-bold uppercase tracking-wider text-navy",
											children: article.category
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5" }), article.date]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 font-serif-hero text-xl sm:text-2xl font-bold text-navy",
										children: article.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base",
										children: article.summary
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex items-center justify-between border-t border-border/70 pt-4 text-xs font-bold text-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: article.readTime }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "/contact",
										className: "inline-flex items-center gap-1 transition-colors hover:text-navy",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Discuss with an Advisor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
									})]
								})]
							}, article.title))
						})
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { ResourcesPage as component };

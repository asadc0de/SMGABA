import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Check, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/real-estate-CUL1oGsw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REAL_ESTATE_SERVICES = [
	{
		title: "Property-Level P&L & Rent Rolls",
		desc: "Detailed property-by-property ledger tracking, tenant lease accounting, and automated Common Area Maintenance (CAM) reconciliations."
	},
	{
		title: "1031 Exchange Advisory",
		desc: "Strategic coordination of like-kind exchange timelines and replacement property capital accounts to defer capital gains tax."
	},
	{
		title: "Depreciation & Cost Segregation",
		desc: "Accelerating tax deductions through bonus depreciation and coordinating certified engineering cost segregation studies."
	},
	{
		title: "Partnership Capital Accounting",
		desc: "Complex waterfall calculations, capital call tracking, distribution schedules, and K-1 preparation for multi-tiered syndications."
	},
	{
		title: "Investor Reporting Packages",
		desc: "Quarterly and annual financial statements formatted for bank lenders, equity partners, and institutional investors."
	},
	{
		title: "Entity Structuring & Asset Protection",
		desc: "Advising on optimal holding structures (LLCs, LPs, REITs) to protect personal assets and minimize overall tax exposure."
	}
];
function RealEstatePage() {
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white text-[#1c2d42] font-sans antialiased selection:bg-blue-100 selection:text-blue-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Industry Practice",
					title: "Real Estate & Development",
					description: "Comprehensive financial stewardship for commercial developers, property management groups, residential landlords, and real estate syndicators across New York, Florida, and nationwide.",
					buttonText: "GET STARTED",
					buttonHref: "#contact-form"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28 bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:gap-16 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-serif-hero text-2xl sm:text-3xl font-bold text-[#142340]",
										children: "Maximizing Portfolio Value"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-serif-hero text-3xl sm:text-4xl font-bold text-[#1e3a6d]",
										children: "Precision Accounting for Property Portfolios"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 space-y-4 text-base text-slate-600 leading-relaxed font-normal",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Real estate transactions require meticulous financial tracking across multiple legal entities, capital accounts, and tax jurisdictions. At SMG, we structure your accounting systems so you have total visibility into property cash flows and return on equity." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Whether you are managing a 50-unit residential portfolio, closing a 1031 exchange, or structuring a multi-million dollar commercial development, our advisors ensure compliance, maximize depreciation, and safeguard your bottom line." })]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-5 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative size-72 sm:size-84 overflow-hidden rounded-full border-4 border-blue-500/20 p-2 shadow-2xl bg-white",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "https://www.smgaba.com/wp-content/uploads/2021/10/AdobeStock_201950021-1.jpeg",
										alt: "Real Estate Accounting",
										className: "size-full rounded-full object-cover"
									})
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-24 bg-[#faf9f6] border-y border-stone-200/70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
								children: "Real Estate Advisory Services"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-base text-slate-600 max-w-2xl mx-auto",
								children: "Tailored accounting architectures designed to maximize tax efficiency and investor transparency."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
							children: REAL_ESTATE_SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-white p-7 border border-stone-200/80 shadow-sm transition-all hover:shadow-md hover:-translate-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-10 items-center justify-center rounded-xl bg-[#14284b] text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5 stroke-[2.5]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 font-serif-hero text-xl font-bold text-[#14284b]",
										children: service.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2.5 text-sm text-slate-600 leading-relaxed font-normal",
										children: service.desc
									})
								]
							}, service.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact-form",
					className: "py-20 sm:py-28 bg-[#0b172e] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Let's Talk Real Estate"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm sm:text-base text-blue-200",
								children: "Book a consultation with our real estate advisory team."
							})]
						}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-blue-400/30 bg-blue-500/10 p-8 text-center backdrop-blur-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-12 text-blue-400" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-serif-hero text-2xl font-bold text-white",
									children: "Thank You!"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-blue-100",
									children: "Your real estate consultation request has been received. We will contact you shortly."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (e) => {
								e.preventDefault();
								setSubmitted(true);
							},
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Your Name *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Company / Portfolio Name",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Email or Phone Number *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Best Time to Contact"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Morning",
											children: "Morning (8:30am – 12:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Afternoon",
											children: "Afternoon (12:00pm – 5:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Evening",
											children: "Evening (5:00pm – 7:00pm)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									placeholder: "Tell us about your portfolio, property count, or tax goals...",
									className: "w-full rounded-xl border border-white/20 bg-white/10 p-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "inline-flex items-center justify-center rounded-full bg-white px-12 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0b172e] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
										children: "SCHEDULE CONSULTATION"
									})
								})
							]
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { RealEstatePage as component };

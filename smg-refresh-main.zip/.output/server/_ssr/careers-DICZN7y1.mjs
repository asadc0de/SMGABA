import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { S as Heart, c as Sparkles, g as MapPin, i as Users, o as TrendingUp, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/careers-DICZN7y1.js
var import_jsx_runtime = require_jsx_runtime();
var PERKS = [
	{
		title: "Continuous Professional Growth",
		desc: "CPA exam reimbursement, sponsored continuing education (CPE), and direct mentorship from seasoned industry partners.",
		icon: TrendingUp
	},
	{
		title: "Collaborative Team Culture",
		desc: "A positive, supportive workplace where initiative is celebrated and high performers are rapidly recognized.",
		icon: Users
	},
	{
		title: "Competitive Compensation & Benefits",
		desc: "Comprehensive health, dental, and vision coverage, 401(k) matching, and generous paid time off.",
		icon: Sparkles
	},
	{
		title: "Work-Life Harmony",
		desc: "Modern hybrid work options, flexible scheduling, and sustainable busy-season workloads designed around well-being.",
		icon: Heart
	}
];
var POSITIONS = [
	{
		title: "Senior Accounting Advisory Manager",
		department: "Client Accounting Services (CAS)",
		location: "Islandia, NY / Hybrid",
		type: "Full-Time",
		desc: "Lead client accounting pods, review monthly financials, mentor associates, and provide strategic advisory to hospitality and business leaders."
	},
	{
		title: "Full-Charge Hospitality Bookkeeper",
		department: "Bookkeeping & Operations",
		location: "New York, NY / Islandia, NY / Hybrid",
		type: "Full-Time",
		desc: "Manage daily ledger reconciliations, payroll batches, inventory data integration, and vendor AP/AR for premier restaurants and bar groups."
	},
	{
		title: "Tax Specialist & Senior Associate",
		department: "Tax Strategy & Compliance",
		location: "St. Petersburg, FL / Remote Available",
		type: "Full-Time",
		desc: "Prepare complex corporate (1120/1120-S/1065) and individual returns, conduct state sales tax reconciliations, and structure tax credits."
	}
];
function CareersPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Join Our Team",
					title: "Careers at SMG",
					description: "At SMG, we empower our team members to grow, innovate, and make a tangible impact on the businesses and communities we serve.",
					buttonText: "VIEW OPEN POSITIONS",
					buttonHref: "#openings"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-2xl text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Why SMG"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-navy",
									children: "Empowering Our People"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-base text-muted-foreground sm:text-lg",
									children: "We believe that delivering high-level client care begins with taking exceptional care of our team."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
							children: PERKS.map((perk) => {
								const Icon = perk.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-surface flex flex-col p-8 transition-all hover:-translate-y-1 hover:shadow-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex size-12 items-center justify-center rounded-2xl bg-navy/5 text-navy",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-6 font-display text-lg font-bold text-navy",
											children: perk.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm leading-relaxed text-muted-foreground",
											children: perk.desc
										})
									]
								}, perk.title);
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y bg-secondary/50",
					id: "positions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto max-w-2xl text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "eyebrow",
										children: "Current Opportunities"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-navy",
										children: "Open Positions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base text-muted-foreground",
										children: "Explore our active openings across our Long Island, Manhattan, and Florida offices."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-14 space-y-6",
								children: POSITIONS.map((pos) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "card-surface p-8 transition-all hover:shadow-xl sm:p-10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-navy/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-navy",
														children: pos.department
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1 text-xs font-semibold text-muted-foreground",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), pos.location]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-bold text-emerald-700",
														children: pos.type
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-3 font-serif-hero text-2xl font-bold text-navy",
												children: pos.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 max-w-3xl text-sm leading-relaxed text-muted-foreground sm:text-base",
												children: pos.desc
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "shrink-0 pt-2 lg:pt-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												className: "bg-navy text-white hover:bg-navy/90",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "mailto:careers@smgaba.com?subject=Application for Position",
													children: ["Apply Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })]
												})
											})
										})]
									})
								}, pos.title))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-12 rounded-3xl bg-mist/60 p-8 text-center sm:p-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl font-bold text-navy",
									children: "Don't see the right role?"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-mist-foreground",
									children: [
										"We are always eager to meet talented accountants, bookkeepers, and advisors. Send your resume to",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "mailto:careers@smgaba.com",
											className: "font-bold underline text-navy",
											children: "careers@smgaba.com"
										})
									]
								})]
							})
						]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { CareersPage as component };

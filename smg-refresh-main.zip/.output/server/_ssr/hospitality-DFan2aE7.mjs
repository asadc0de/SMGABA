import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { L as Award, M as Check, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hospitality-DFan2aE7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HOSPITALITY_SERVICES = [
	{
		title: "Weekly Prime Cost Tracking",
		desc: "Labor and Cost of Goods Sold (COGS) are calculated and benchmarked weekly to maintain a healthy operating margin below 60%."
	},
	{
		title: "Tipped Payroll & FICA Compliance",
		desc: "Seamless tip pool calculations, 80/20 rule adherence, and maximizing Section 45B employer FICA tip tax credits."
	},
	{
		title: "POS & Inventory Batching",
		desc: "Automated daily integration with Toast, Square, Clover, Aloha, Restaurant365, and MarginEdge."
	},
	{
		title: "Sales Tax Audit Defense",
		desc: "Strict multi-jurisdiction sales tax compliance and audit representation for New York, Florida, and multi-state operations."
	},
	{
		title: "Multi-Location Financial Consolidation",
		desc: "Store-by-store comparative P&Ls, centralized vendor AP batching, and executive cash flow reporting."
	},
	{
		title: "Menu Engineering & Profitability Analysis",
		desc: "Detailed plate costing and margin breakdown to identify high-profit contributors and optimize menu pricing."
	}
];
function HospitalityPage() {
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white text-[#1c2d42] font-sans antialiased selection:bg-blue-100 selection:text-blue-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Industry Practice",
					title: "Hospitality & Restaurants",
					description: "From single-location dining to multi-unit hospitality groups, SMG provides the specialized back-office systems, prime cost control, and tax strategies essential for running profitable food and beverage operations.",
					buttonText: "GET STARTED",
					buttonHref: "#contact-form"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28 bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:gap-16 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-serif-hero text-2xl sm:text-3xl font-bold text-[#142340]",
										children: "We Know the Hospitality Industry"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-serif-hero text-3xl sm:text-4xl font-bold text-[#1e3a6d]",
										children: "Mastering the Numbers Behind the Kitchen"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 space-y-4 text-base text-slate-600 leading-relaxed font-normal",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "SMG is a proud partner of the New York State Restaurant Association, the New York City Hospitality Alliance, and the National Restaurant Association. We manage financials for high-volume restaurants, cocktail lounges, bakeries, caterers, and nightlife groups nationwide." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Our goal is to increase your net profitability while letting you do what you do best: manage your front of the house, craft menus, run your kitchen, or expand to new locations." })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 flex flex-wrap items-center gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 rounded-xl bg-slate-50 border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-700",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NYC Hospitality Alliance Member" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 rounded-xl bg-slate-50 border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-700",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NYS Restaurant Association" })]
										})]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-5 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative size-72 sm:size-84 overflow-hidden rounded-full border-4 border-blue-500/20 p-2 shadow-2xl bg-white",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "https://www.smgaba.com/wp-content/uploads/2021/11/home-feature-hospitality.jpg",
										alt: "Hospitality Accounting",
										className: "size-full rounded-full object-cover"
									})
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-24 bg-[#faf9f6] border-y border-stone-200/70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
								children: "Hospitality Advisory Services"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-base text-slate-600 max-w-2xl mx-auto",
								children: "Purpose-built accounting frameworks engineered specifically for food & beverage profitability."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-3",
							children: HOSPITALITY_SERVICES.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-white p-7 border border-stone-200/80 shadow-sm transition-all hover:shadow-md hover:-translate-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-10 items-center justify-center rounded-xl bg-[#14284b] text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5 stroke-[2.5]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 font-serif-hero text-xl font-bold text-[#14284b]",
										children: service.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2.5 text-sm text-slate-600 leading-relaxed font-normal",
										children: service.desc
									})
								]
							}, service.title))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact-form",
					className: "py-20 sm:py-28 bg-[#0b172e] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Let's Talk Hospitality"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm sm:text-base text-blue-200",
								children: "Book a consultation with our specialized hospitality team."
							})]
						}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-blue-400/30 bg-blue-500/10 p-8 text-center backdrop-blur-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-12 text-blue-400" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-serif-hero text-2xl font-bold text-white",
									children: "Thank You!"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-blue-100",
									children: "Your hospitality consultation request has been received. We will contact you shortly."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (e) => {
								e.preventDefault();
								setSubmitted(true);
							},
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Your Name *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Restaurant / Venue Name",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Email or Phone Number *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Best Time to Contact"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Morning",
											children: "Morning (8:30am – 12:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Afternoon",
											children: "Afternoon (12:00pm – 5:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Evening",
											children: "Evening (5:00pm – 7:00pm)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									placeholder: "Tell us about your restaurant, locations, or current POS systems...",
									className: "w-full rounded-xl border border-white/20 bg-white/10 p-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "inline-flex items-center justify-center rounded-full bg-white px-12 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0b172e] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
										children: "SCHEDULE CONSULTATION"
									})
								})
							]
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { HospitalityPage as component };

import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { O as Clock, g as MapPin, m as Phone, p as Printer, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
import { t as QuoteForm } from "./QuoteForm-WvWZC6iv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-york-city-location-B9rWs7gy.js
var import_jsx_runtime = require_jsx_runtime();
function ManhattanLocationPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Manhattan Location",
					title: "New York City",
					description: "In the heart of Manhattan on Seventh Avenue, serving restaurant operators, hospitality groups, and enterprises across the 5 boroughs."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:gap-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-surface p-8 sm:p-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "eyebrow",
											children: "Manhattan Practice"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-3 font-serif-hero text-3xl font-bold text-navy",
											children: "Seventh Avenue Office"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-6 space-y-5 text-sm sm:text-base text-foreground/90",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-1 size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-semibold text-navy",
														children: "561 Seventh Avenue, 9th Floor"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-muted-foreground",
														children: "New York, NY 10018"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs uppercase text-muted-foreground font-semibold",
														children: "Direct Phone"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: "tel:2122034700",
														className: "font-bold text-navy hover:text-primary transition-colors text-lg",
														children: "(212) 203-4700"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs uppercase text-muted-foreground font-semibold",
														children: "Fax"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-medium text-navy",
														children: "(631) 481-8601"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "border-t border-border pt-5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-start gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-1 size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "text-xs uppercase text-muted-foreground font-semibold",
																children: "Hours of Operation"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "mt-1 space-y-1 text-sm text-foreground/90",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Monday – Friday: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "8:30am – 5:30pm" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Saturday*: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "9:00am – 5:00pm" })] })]
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "mt-2 text-xs text-muted-foreground",
																children: "*Saturday hours apply during tax season (Jan 1 – Apr 15)"
															})
														] })]
													})
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-8 flex flex-col gap-3 sm:flex-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												className: "w-full sm:w-auto bg-navy text-white hover:bg-navy/90",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "/contact",
													children: ["Schedule Consultation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })]
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												variant: "outline",
												className: "w-full sm:w-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "https://maps.google.com/?q=561+Seventh+Avenue+New+York+NY+10018",
													target: "_blank",
													rel: "noreferrer",
													children: "Get Directions"
												})
											})]
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative aspect-4/3 w-full overflow-hidden rounded-3xl border border-border shadow-xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
										title: "SMG Manhattan Location Map",
										src: "https://maps.google.com/maps?q=561+Seventh+Avenue+New+York+NY+10018&t=&z=14&ie=UTF8&iwloc=&output=embed",
										className: "size-full border-0",
										loading: "lazy"
									})
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { ManhattanLocationPage as component };

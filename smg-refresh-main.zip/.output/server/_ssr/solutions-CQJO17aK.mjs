import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Check, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/solutions-CQJO17aK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SOLUTIONS_DATA = [
	{
		id: "outsourced-bookkeeping",
		title: "Outsourced Bookkeeping",
		subtitle: "Let our professionals take care of your day-to-day accounting needs.",
		points: [
			"Reliable, Responsive Bookkeeping",
			"Dedicated Team Member",
			"General Ledger & Bookkeeping",
			"Seamless Onboarding",
			"Communication with Care"
		],
		image: "https://www.smgaba.com/wp-content/uploads/2021/11/smg-bookkeeping-1.jpeg",
		reverse: false,
		bgClass: "bg-white"
	},
	{
		id: "cfo-on-the-go",
		title: "CFO on the Go",
		subtitle: "Don't need a full-time CFO? Our experts can fill those shoes with top-level financial management.",
		points: [
			"Treasurer Conversations / Dedicated CFO as a Partner of the Day",
			"Budgeting & Forecasting",
			"Cash Flow Analysis",
			"Key Performance Indicator Evaluation",
			"Profitability Analysis"
		],
		image: "https://www.smgaba.com/wp-content/uploads/2021/10/AdobeStock_201950021-1.jpeg",
		reverse: true,
		bgClass: "bg-[#faf9f6]"
	},
	{
		id: "tax-services",
		title: "Tax Services",
		subtitle: "Leave the stress of tax preparation to us.",
		points: [
			"Trusted Experts",
			"Tax Planning & Preparation",
			"Multi-State Filing & Representation",
			"Partnership & Corporate Returns",
			"Compliance & Regulation"
		],
		image: "https://www.smgaba.com/wp-content/uploads/2021/11/smg-tax-services-1.jpeg",
		reverse: false,
		bgClass: "bg-white"
	},
	{
		id: "back-office",
		title: "Back Office",
		subtitle: "Our seasoned team is dedicated to providing you the edge you need.",
		points: [
			"Payroll Reconciliation",
			"Receivables & Payables",
			"Due Diligence Support",
			"System Realignment and Optimization",
			"Vendor Relationship",
			"Third Party Integration"
		],
		image: "https://www.smgaba.com/wp-content/uploads/2021/11/smg-back-office-1.jpeg",
		reverse: true,
		bgClass: "bg-[#faf9f6]"
	}
];
var TESTIMONIALS = [
	{
		quote: "SMG has provided our business and personal accounting for years. I can't imagine not having them in our corner. SMG provides peace of mind.",
		author: "Michael M.",
		company: "JRM",
		subtitle: "JRM Construction Management"
	},
	{
		quote: "Their team transformed our restaurant financials with weekly prime cost tracking, multi-unit batching, and immaculate P&Ls.",
		author: "Anthony G.",
		company: "HOSPITALITY",
		subtitle: "Harbor View Hospitality"
	},
	{
		quote: "The CFO on the Go program allowed us to model cash projections accurately and secure commercial bank financing with total ease.",
		author: "David K.",
		company: "TRI-STATE",
		subtitle: "Tri-State Development"
	}
];
function SolutionsPage() {
	const [activeTestimonial, setActiveTestimonial] = (0, import_react.useState)(0);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white text-[#1c2d42] font-sans antialiased selection:bg-blue-100 selection:text-blue-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1920&q=80",
					title: "Solutions",
					description: "SMG offers a wide range of financial services provided by our specialized staff to ensure the smooth running of the back-end operations for a variety of businesses.",
					buttonText: "CONTACT US",
					buttonHref: "#contact-form"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "py-16 sm:py-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center mb-16 px-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
							children: "Catering Solutions For All Industries"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-0",
						children: SOLUTIONS_DATA.map((solution) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							id: solution.id,
							className: `py-16 sm:py-24 ${solution.bgClass} border-b border-stone-200/50 last:border-0`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto max-w-6xl px-6 lg:px-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-12 lg:grid-cols-12 lg:gap-16 items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `lg:col-span-7 ${solution.reverse ? "lg:order-2" : "lg:order-1"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-serif-hero text-2xl sm:text-3xl lg:text-4xl font-bold text-[#142340]",
												children: solution.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-base sm:text-lg text-slate-600 font-normal",
												children: solution.subtitle
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "mt-8 space-y-4",
												children: solution.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-start gap-3.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "mt-1 flex size-5 shrink-0 items-center justify-center rounded-full bg-[#1b4e94] text-white",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3 stroke-[3]" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm sm:text-base font-medium text-slate-700 leading-relaxed",
														children: point
													})]
												}, point))
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `lg:col-span-5 flex justify-center ${solution.reverse ? "lg:order-1" : "lg:order-2"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative size-72 sm:size-84 overflow-hidden rounded-full border-4 border-[#3b82f6]/20 p-2 shadow-2xl bg-white",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: solution.image,
												alt: solution.title,
												className: "size-full rounded-full object-cover",
												loading: "lazy"
											})
										})
									})]
								})
							})
						}, solution.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 bg-[#0f2142] text-white relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto max-w-4xl px-6 lg:px-10 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Here's Why We're Recommended"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative my-12 px-4 sm:px-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto mb-8 flex size-24 items-center justify-center rounded-full bg-white text-[#0a1730] font-serif-hero text-base font-black tracking-wider p-2 shadow-2xl",
										children: TESTIMONIALS[activeTestimonial].company
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-serif-hero text-xl sm:text-2xl md:text-3xl italic text-slate-100 leading-relaxed max-w-2xl mx-auto",
										children: [
											"\"",
											TESTIMONIALS[activeTestimonial].quote,
											"\""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 text-sm font-semibold text-blue-300",
										children: ["— ", TESTIMONIALS[activeTestimonial].author]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-center gap-2 mb-10",
								children: TESTIMONIALS.map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setActiveTestimonial(idx),
									className: `size-2.5 rounded-full transition-all ${activeTestimonial === idx ? "w-7 bg-white" : "bg-white/30"}`,
									"aria-label": `Testimonial slide ${idx + 1}`
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/testimonials",
								className: "inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0f2142] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
								children: "SEE ALL TESTIMONIALS"
							}) })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact-form",
					className: "py-20 sm:py-28 bg-[#0b172e] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Let's Talk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm sm:text-base text-blue-200",
								children: "How We Can Help?"
							})]
						}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-blue-400/30 bg-blue-500/10 p-8 text-center backdrop-blur-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-12 text-blue-400" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-serif-hero text-2xl font-bold text-white",
									children: "Thank You!"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-blue-100",
									children: "Your message has been received. Our team will contact you shortly."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (e) => {
								e.preventDefault();
								setSubmitted(true);
							},
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Your Name *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Company Name",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Email or Phone Number *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Best Time to Contact"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Morning",
											children: "Morning (8:30am – 12:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Afternoon",
											children: "Afternoon (12:00pm – 5:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Evening",
											children: "Evening (5:00pm – 7:00pm)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Services"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Outsourced Bookkeeping",
											children: "Outsourced Bookkeeping"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "CFO on the Go",
											children: "CFO on the Go"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Tax Services",
											children: "Tax Services"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Back Office",
											children: "Back Office Management"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Hospitality Accounting",
											children: "Hospitality & Restaurant Practice"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									placeholder: "Comments",
									className: "w-full rounded-xl border border-white/20 bg-white/10 p-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										id: "optin-check-solutions",
										required: true,
										className: "mt-1 size-4 rounded border-white/20 bg-white/10 text-blue-500 focus:ring-0"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "optin-check-solutions",
										className: "text-xs text-slate-300/90 leading-relaxed",
										children: "I agree to receive messages and updates from SMG Accounting & Advisory."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.7rem] text-slate-400/80 pt-1 leading-relaxed",
									children: "By submitting this form, you consent to our communication regarding your inquiry. Your information is kept strictly confidential."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "inline-flex items-center justify-center rounded-full bg-white px-12 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0b172e] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
										children: "SEND"
									})
								})
							]
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { SolutionsPage as component };

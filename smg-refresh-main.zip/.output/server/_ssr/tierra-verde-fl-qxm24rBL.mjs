import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { O as Clock, g as MapPin, m as Phone, p as Printer, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
import { t as QuoteForm } from "./QuoteForm-WvWZC6iv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tierra-verde-fl-qxm24rBL.js
var import_jsx_runtime = require_jsx_runtime();
function TierraVerdeLocationPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Florida Regional Office",
					title: "St. Petersburg, FL",
					description: "Serving the Tampa Bay, Clearwater, and Gulf Coast hospitality and business communities with dedicated on-the-ground advisory."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:gap-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "card-surface p-8 sm:p-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "eyebrow",
											children: "Florida Practice"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-3 font-serif-hero text-3xl font-bold text-navy",
											children: "St. Petersburg Regional Office"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-6 space-y-5 text-sm sm:text-base text-foreground/90",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-1 size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-semibold text-navy",
														children: "646 94th Ave N"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-muted-foreground",
														children: "St. Petersburg, FL 33702"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs uppercase text-muted-foreground font-semibold",
														children: "Direct Phone"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: "tel:7273883378",
														className: "font-bold text-navy hover:text-primary transition-colors text-lg",
														children: "(727) 388-3378"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs uppercase text-muted-foreground font-semibold",
														children: "Fax"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-medium text-navy",
														children: "(727) 318-4096"
													})] })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "border-t border-border pt-5",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-start gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-1 size-5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-xs uppercase text-muted-foreground font-semibold",
															children: "Hours of Operation"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "mt-1 space-y-1 text-sm text-foreground/90",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Monday – Friday: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "9:00am – 5:00pm" })] })
														})] })]
													})
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-8 flex flex-col gap-3 sm:flex-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												className: "w-full sm:w-auto bg-navy text-white hover:bg-navy/90",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: "/contact",
													children: ["Schedule Consultation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 size-4" })]
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												asChild: true,
												size: "lg",
												variant: "outline",
												className: "w-full sm:w-auto",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "https://maps.google.com/?q=646+94th+Ave+N+St+Petersburg+FL+33702",
													target: "_blank",
													rel: "noreferrer",
													children: "Get Directions"
												})
											})]
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative aspect-4/3 w-full overflow-hidden rounded-3xl border border-border shadow-xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
										title: "SMG Florida Location Map",
										src: "https://maps.google.com/maps?q=646+94th+Ave+N+St+Petersburg+FL+33702&t=&z=14&ie=UTF8&iwloc=&output=embed",
										className: "size-full border-0",
										loading: "lazy"
									})
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { TierraVerdeLocationPage as component };

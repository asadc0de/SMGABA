import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
import { t as QuoteForm } from "./QuoteForm-WvWZC6iv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/our-team-DM3QraNL.js
var import_jsx_runtime = require_jsx_runtime();
var TEAM = [
	{
		name: "Scott Melchiorre",
		role: "Managing Principal & Founder",
		bio: "With over two decades of experience in commercial accounting, hospitality finance, and executive advisory, Scott leads SMG with a commitment to high-touch client relationships and strategic excellence.",
		avatar: "https://www.smgaba.com/wp-content/uploads/2021/11/home-feature-hospitality.jpg"
	},
	{
		name: "Senior Accounting Advisory Team",
		role: "Client Accounting Services (CAS)",
		bio: "Our team of seasoned CPAs and senior accountants manage full-charge bookkeeping, monthly closings, custom KPI reporting, and strategic tax planning for our diverse clientele.",
		avatar: "https://www.smgaba.com/wp-content/uploads/2021/10/AdobeStock_201950021-1.jpeg"
	},
	{
		name: "Tax Strategy & Compliance Group",
		role: "Multi-State Tax & Audit Defense",
		bio: "Specializing in corporate returns, state sales tax audits, FICA tip credits, and proactive year-round tax sheltering for high-growth enterprises and property syndicates.",
		avatar: "https://www.smgaba.com/wp-content/uploads/2021/11/smg-tax-services-1.jpeg"
	},
	{
		name: "Hospitality Operations Specialists",
		role: "Restaurant Back-Office & Payroll",
		bio: "Dedicated industry specialists who interface directly with restaurant general managers, POS providers, and food distributors to maintain daily ledger accuracy and prime cost control.",
		avatar: "https://www.smgaba.com/wp-content/uploads/2021/11/smg-back-office-1.jpeg"
	}
];
function OurTeamPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "People Behind Your Success",
					title: "Our Team",
					description: "Experienced CPAs, dedicated bookkeepers, and executive CFO advisors who act as an integral extension of your internal operations.",
					buttonText: "WORK WITH US",
					buttonHref: "/contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-3xl text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Dedicated Client Pods"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-navy",
									children: "No Generic Call Centers. Just Direct Access."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg",
									children: "Every SMG client is paired with a dedicated accountant and client manager who understand your chart of accounts, operational bottlenecks, and strategic milestones."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-2",
							children: TEAM.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-surface overflow-hidden p-8 transition-all hover:-translate-y-1 hover:shadow-2xl sm:p-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-6 sm:flex-row sm:items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: member.avatar,
											alt: member.name,
											className: "size-24 rounded-2xl object-cover shadow-md sm:size-28"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold uppercase tracking-wider text-primary",
											children: member.role
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-1 font-serif-hero text-2xl font-bold text-navy",
											children: member.name
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-sm leading-relaxed text-muted-foreground sm:text-base",
										children: member.bio
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 border-t border-border/80 pt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "/contact",
											className: "inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-navy transition-colors hover:text-primary",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Schedule Meeting with Team" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
										})
									})
								]
							}, member.name))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { OurTeamPage as component };

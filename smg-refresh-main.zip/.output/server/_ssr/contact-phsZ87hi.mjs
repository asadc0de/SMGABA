import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { O as Clock, g as MapPin, m as Phone, p as Printer } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
import { t as QuoteForm } from "./QuoteForm-WvWZC6iv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-phsZ87hi.js
var import_jsx_runtime = require_jsx_runtime();
var LOCATIONS = [
	{
		name: "Long Island (Corporate HQ)",
		address: ["300 Corporate Plaza", "Islandia, NY 11749"],
		phone: "(631) 481-8600",
		fax: "(631) 481-8601",
		hours: ["Monday–Friday: 8:30am – 5:30pm", "Saturday*: 9:00am – 5:00pm"],
		href: "/islandia-location"
	},
	{
		name: "Manhattan Office",
		address: ["561 Seventh Avenue, 9th Floor", "New York, NY 10018"],
		phone: "(212) 203-4700",
		fax: "(631) 481-8601",
		hours: ["Monday–Friday: 8:30am – 5:30pm", "Saturday*: 9:00am – 5:00pm"],
		href: "/new-york-city-location"
	},
	{
		name: "Florida Regional Office",
		address: ["646 94th Ave N", "St. Petersburg, FL 33702"],
		phone: "(727) 388-3378",
		fax: "(727) 318-4096",
		hours: ["Monday–Friday: 9:00am – 5:00pm"],
		href: "/tierra-verde-fl"
	}
];
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1920&q=80",
					eyebrow: "Get In Touch",
					title: "Contact Us",
					description: "We are ready to answer your questions, assess your current bookkeeping architecture, and outline a tailored roadmap for financial growth."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section-y",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-6 lg:px-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-8 lg:grid-cols-3",
							children: LOCATIONS.map((loc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "card-surface flex flex-col justify-between p-8 sm:p-10",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold uppercase tracking-widest text-primary",
										children: "Office Hub"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-serif-hero text-2xl font-bold text-navy",
										children: loc.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 space-y-4 text-sm text-foreground/90",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: loc.address.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: line }, line)) })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: `tel:${loc.phone.replace(/[^0-9]/g, "")}`,
													className: "font-semibold text-navy hover:text-primary transition-colors",
													children: loc.phone
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3 text-muted-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["FAX: ", loc.fax] })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "border-t border-border/80 pt-4",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs text-muted-foreground space-y-1",
														children: loc.hours.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: h }, h))
													})]
												})
											})
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 pt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										className: "w-full",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: loc.href,
											children: "View Location Details"
										})
									})
								})]
							}, loc.name))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-center text-xs text-muted-foreground",
							children: "*Saturday hours apply during tax season (January 1 – April 15)"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { ContactPage as component };

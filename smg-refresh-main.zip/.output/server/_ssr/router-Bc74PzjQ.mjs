import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Bc74PzjQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DjjGGLkd.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$20 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Lovable App" },
			{
				name: "description",
				content: "Lovable Generated Project"
			},
			{
				name: "author",
				content: "Lovable"
			},
			{
				property: "og:title",
				content: "Lovable App"
			},
			{
				property: "og:description",
				content: "Lovable Generated Project"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$20.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$19 = () => import("./routes-Dimfq-O0.mjs");
var HERO_IMAGE = "https://www.smgaba.com/wp-content/uploads/2021/11/smg-wallpaper.jpg";
var Route$19 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "SMG | Accounting, Bookkeeping & Advisory for Hospitality, Real Estate & SMBs" },
		{
			name: "description",
			content: "SMG is a full-service accounting, bookkeeping, and executive advisory firm serving hospitality, real estate, and growth-oriented businesses across NY and FL."
		},
		{
			property: "og:title",
			content: "SMG | Accounting, Bookkeeping & Advisory"
		},
		{
			property: "og:description",
			content: "Building relationships with passion, care & responsiveness. Outsourced bookkeeping, CFO on the Go, tax services and back office support."
		},
		{
			property: "og:image",
			content: HERO_IMAGE
		},
		{
			name: "twitter:image",
			content: HERO_IMAGE
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./about-us-DphCJ8Oh.mjs");
var Route$18 = createFileRoute("/about-us")({
	head: () => ({ meta: [{ title: "About Us | SMG Accounting & Advisory" }, {
		name: "description",
		content: "Discover the SMG advantage. Dedicated accounting, bookkeeping, and CFO advisory built on passion, care, and responsiveness."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./automotive-Cl6vCU0T.mjs");
var Route$17 = createFileRoute("/automotive")({
	head: () => ({ meta: [{ title: "Automotive Accounting & Dealership Advisory | SMG" }, {
		name: "description",
		content: "Specialized accounting for auto dealerships, collision centers, and repair facilities. Floor plan audits, parts inventory, and warranty claims accounting."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./careers-DICZN7y1.mjs");
var Route$16 = createFileRoute("/careers")({
	head: () => ({ meta: [{ title: "Careers | Join the SMG Team" }, {
		name: "description",
		content: "Explore career opportunities at SMG. Join our dynamic team of accountants, bookkeepers, and financial advisors in New York and Florida."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./construction-BygV2wd3.mjs");
var Route$15 = createFileRoute("/construction")({
	head: () => ({ meta: [{ title: "Construction Accounting & Contractor Advisory | SMG" }, {
		name: "description",
		content: "Specialized financial management for general contractors, specialty subcontractors, and civil builders. Job costing, AIA progress billing, and bonding capacity."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./contact-phsZ87hi.mjs");
var Route$14 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact Us | SMG Accounting, Bookkeeping & Advisory" }, {
		name: "description",
		content: "Connect with SMG's offices in Long Island, Manhattan, and Florida. Schedule a consultation or contact our advisory team directly."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./healthcare-CVCfl_jS.mjs");
var Route$13 = createFileRoute("/healthcare")({
	head: () => ({ meta: [{ title: "Healthcare & Medical Practice Accounting | SMG" }, {
		name: "description",
		content: "Specialized financial management for medical practices, dental clinics, surgical centers, and healthcare providers. Physician comp, billing audits, and tax strategy."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./hospitality-DFan2aE7.mjs");
var Route$12 = createFileRoute("/hospitality")({
	head: () => ({ meta: [{ title: "Hospitality Accounting & Advisory | SMG" }, {
		name: "description",
		content: "Specialized restaurant, bar, and hospitality accounting. Weekly prime cost control, tipped payroll compliance, and POS integrations."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./industries-BtDMXGYG.mjs");
var Route$11 = createFileRoute("/industries")({
	head: () => ({ meta: [{ title: "Industries | SMG Accounting & Advisory" }, {
		name: "description",
		content: "Specialized financial expertise across Hospitality, Real Estate, Automotive, Healthcare, Legal, Construction, Manufacturing, and Retail."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./islandia-location-BV0GTXbi.mjs");
var Route$10 = createFileRoute("/islandia-location")({
	head: () => ({ meta: [{ title: "Long Island Office | SMG Corporate Headquarters Islandia NY" }, {
		name: "description",
		content: "Visit SMG's Long Island corporate headquarters at 300 Corporate Plaza, Islandia NY. Full-service accounting, bookkeeping, and advisory."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./legal-professionals-QHNQ365Y.mjs");
var Route$9 = createFileRoute("/legal-professionals")({
	head: () => ({ meta: [{ title: "Legal Accounting & Law Firm Advisory | SMG" }, {
		name: "description",
		content: "Specialized financial management for law firms, solo attorneys, and legal practices. IOLTA trust compliance, partner distributions, and billable realization analysis."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./manufacturers-605uGNJ9.mjs");
var Route$8 = createFileRoute("/manufacturers")({
	head: () => ({ meta: [{ title: "Manufacturing & Distribution Accounting | SMG" }, {
		name: "description",
		content: "Specialized cost accounting for manufacturers, assemblers, and wholesale distributors. Bill of Materials costing, supply chain cash flow, and R&D tax credits."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./new-york-city-location-B9rWs7gy.mjs");
var Route$7 = createFileRoute("/new-york-city-location")({
	head: () => ({ meta: [{ title: "Manhattan NYC Office | SMG Accounting & Advisory" }, {
		name: "description",
		content: "Visit SMG's Manhattan office located at 561 Seventh Avenue, 9th Floor, New York, NY. Specialized NYC hospitality and corporate advisory."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./our-team-DM3QraNL.mjs");
var Route$6 = createFileRoute("/our-team")({
	head: () => ({ meta: [{ title: "Our Team | SMG Accounting & Advisory" }, {
		name: "description",
		content: "Meet the experienced partners, certified accountants, and financial advisors at SMG dedicated to your business success."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./real-estate-CUL1oGsw.mjs");
var Route$5 = createFileRoute("/real-estate")({
	head: () => ({ meta: [{ title: "Real Estate Accounting & Advisory | SMG" }, {
		name: "description",
		content: "Comprehensive accounting for property developers, syndicators, and real estate management firms. 1031 exchanges, CAM reconciliations, and partnership returns."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./resources-Dy_ZDJxy.mjs");
var Route$4 = createFileRoute("/resources")({
	head: () => ({ meta: [{ title: "Resources & Newsletters | SMG Advisory Insights" }, {
		name: "description",
		content: "Stay up to date with the latest hospitality legislation, restaurant cost management strategies, tax updates, and business insights from SMG."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./retail-ncZJHVG0.mjs");
var Route$3 = createFileRoute("/retail")({
	head: () => ({ meta: [{ title: "Retail & Multi-Location Commerce Accounting | SMG" }, {
		name: "description",
		content: "Specialized financial management for retail stores, boutique chains, franchises, and omni-channel e-commerce. POS sync, inventory turns, and multi-state sales tax."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./solutions-CQJO17aK.mjs");
var Route$2 = createFileRoute("/solutions")({
	head: () => ({ meta: [{ title: "Solutions | SMG Accounting, Bookkeeping & Advisory" }, {
		name: "description",
		content: "Explore SMG's financial solutions: Outsourced Bookkeeping, CFO on the Go, Tax Services, and Back Office Management tailored for your business."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./testimonials-CaXw-ov1.mjs");
var Route$1 = createFileRoute("/testimonials")({
	head: () => ({ meta: [{ title: "Testimonials & Client Reviews | SMG Accounting" }, {
		name: "description",
		content: "Read reviews and success stories from restaurant groups, real estate developers, and businesses who partner with SMG Accounting, Bookkeeping & Advisory."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tierra-verde-fl-qxm24rBL.mjs");
var Route = createFileRoute("/tierra-verde-fl")({
	head: () => ({ meta: [{ title: "Florida Office | SMG Accounting St. Petersburg FL" }, {
		name: "description",
		content: "Visit SMG's Florida regional office at 646 94th Ave N, St. Petersburg FL. Full-service hospitality and small business advisory in the Tampa Bay area."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$19.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$20
	}),
	AboutUsRoute: Route$18.update({
		id: "/about-us",
		path: "/about-us",
		getParentRoute: () => Route$20
	}),
	AutomotiveRoute: Route$17.update({
		id: "/automotive",
		path: "/automotive",
		getParentRoute: () => Route$20
	}),
	CareersRoute: Route$16.update({
		id: "/careers",
		path: "/careers",
		getParentRoute: () => Route$20
	}),
	ConstructionRoute: Route$15.update({
		id: "/construction",
		path: "/construction",
		getParentRoute: () => Route$20
	}),
	ContactRoute: Route$14.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$20
	}),
	HealthcareRoute: Route$13.update({
		id: "/healthcare",
		path: "/healthcare",
		getParentRoute: () => Route$20
	}),
	HospitalityRoute: Route$12.update({
		id: "/hospitality",
		path: "/hospitality",
		getParentRoute: () => Route$20
	}),
	IndustriesRoute: Route$11.update({
		id: "/industries",
		path: "/industries",
		getParentRoute: () => Route$20
	}),
	IslandiaLocationRoute: Route$10.update({
		id: "/islandia-location",
		path: "/islandia-location",
		getParentRoute: () => Route$20
	}),
	LegalProfessionalsRoute: Route$9.update({
		id: "/legal-professionals",
		path: "/legal-professionals",
		getParentRoute: () => Route$20
	}),
	ManufacturersRoute: Route$8.update({
		id: "/manufacturers",
		path: "/manufacturers",
		getParentRoute: () => Route$20
	}),
	NewYorkCityLocationRoute: Route$7.update({
		id: "/new-york-city-location",
		path: "/new-york-city-location",
		getParentRoute: () => Route$20
	}),
	OurTeamRoute: Route$6.update({
		id: "/our-team",
		path: "/our-team",
		getParentRoute: () => Route$20
	}),
	RealEstateRoute: Route$5.update({
		id: "/real-estate",
		path: "/real-estate",
		getParentRoute: () => Route$20
	}),
	ResourcesRoute: Route$4.update({
		id: "/resources",
		path: "/resources",
		getParentRoute: () => Route$20
	}),
	RetailRoute: Route$3.update({
		id: "/retail",
		path: "/retail",
		getParentRoute: () => Route$20
	}),
	SolutionsRoute: Route$2.update({
		id: "/solutions",
		path: "/solutions",
		getParentRoute: () => Route$20
	}),
	TestimonialsRoute: Route$1.update({
		id: "/testimonials",
		path: "/testimonials",
		getParentRoute: () => Route$20
	}),
	TierraVerdeFlRoute: Route.update({
		id: "/tierra-verde-fl",
		path: "/tierra-verde-fl",
		getParentRoute: () => Route$20
	})
};
var routeTree = Route$20._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };

import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Check, O as Clock, S as Heart, i as Users, k as CircleCheck, u as Shield, y as Lightbulb } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-us-DphCJ8Oh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CORE_VALUES = [
	{
		icon: Users,
		label: "Dedicated Team"
	},
	{
		icon: Clock,
		label: "Responsiveness"
	},
	{
		icon: Shield,
		label: "Integrity"
	},
	{
		icon: Lightbulb,
		label: "Value, Accuracy and Accessibility"
	},
	{
		icon: Heart,
		label: "Execute with Passion"
	}
];
var FIVE_BENEFITS = [
	"Dedicated Team Member",
	"Industry Specialists",
	"Seasoned By Trend & Technology By Day",
	"Advanced Tech Systems",
	"Long-Term Partners"
];
var TESTIMONIALS = [
	{
		quote: "SMG has provided an exceptional level of service for all our business accounting needs.",
		author: "Michael R.",
		company: "THE BAGEL BOSS"
	},
	{
		quote: "Their team transformed our restaurant financials with weekly prime cost tracking and immaculate P&Ls.",
		author: "Anthony G.",
		company: "HOSPITALITY PARTNERS"
	},
	{
		quote: "Having a responsive advisory team who knows multi-entity tax and 1031 exchanges gives us total confidence.",
		author: "David K.",
		company: "TRI-STATE DEVELOPMENT"
	}
];
function AboutUsPage() {
	const [activeTestimonial, setActiveTestimonial] = (0, import_react.useState)(0);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white text-[#1c2d42] font-sans antialiased selection:bg-blue-100 selection:text-blue-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
					bgImage: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=1920&q=80",
					title: "About Us",
					description: "Get a premier, customized financial, accounting and advisory plan or environment that is accurate, responsive and crafted for you and your business. We focus on long-term client engagement and partnerships.",
					buttonText: "MEET OUR TEAM",
					buttonHref: "/our-team"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28 bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-4xl px-6 lg:px-10 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-2xl sm:text-3xl font-bold text-[#142340] tracking-tight",
								children: "The SMG Advantage"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1e3a6d]",
								children: "Changing the Game"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 space-y-6 text-left text-base sm:text-[1.05rem] leading-relaxed text-slate-600 font-normal",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "SMG provides accounting, bookkeeping and account management to diverse businesses and individuals. Whether business, personal or non-profit we partner and work with you to understand your real-time." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The culmination of the benefits of selecting SMG is high quality client relationship and partnering with you to grow your business while saving you time and money. We strive to become an integral part of your team, knowing you, your employees and your operations. We focus on long-term, high quality client relationships by creating strategic partnerships which grow on the foundation of trust." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Past business challenges are often due to inefficient bookkeeping, cash management, reporting and tax. Other reasons include improper preparation, untimely advice and lack of foresight. We emphasize the short, mid and long term to focus on creating solutions that allow you to focus on your business while feeling secure with accounting matters that affect you." })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/contact",
									className: "inline-flex items-center justify-center rounded-full bg-[#1b2d4f] px-9 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-white shadow-lg transition-all hover:bg-[#243c68] hover:scale-105 active:scale-95",
									children: "WORK WITH US"
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-24 bg-[#faf9f6] border-y border-stone-200/70",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-10 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
							children: "Our Core Values"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-14 grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-5 items-start justify-center",
							children: CORE_VALUES.map((val) => {
								const Icon = val.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center text-center group",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-24 sm:size-28 items-center justify-center rounded-full bg-[#14284b] text-white shadow-md transition-transform duration-300 group-hover:scale-110 group-hover:shadow-xl",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-10 sm:size-12 stroke-[1.5]" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-5 font-serif-hero text-base sm:text-lg font-bold text-[#14284b] max-w-[160px] leading-snug",
										children: val.label
									})]
								}, val.label);
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-gradient-to-r from-[#17488c] via-[#1d57a8] to-[#17488c] py-16 text-center text-white shadow-inner",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-4xl px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl font-bold text-white",
								children: "Our Mission"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-lg sm:text-xl text-blue-50 font-normal",
								children: "Building Relationships with Passion, Care, & Responsiveness."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contact-form",
									className: "inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#17488c] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
									children: "GET A QUOTE"
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28 bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-6 lg:px-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center mb-16",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
								children: "Why Work With Us"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:gap-16 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif-hero text-2xl sm:text-3xl font-bold text-[#1a335c]",
									children: "Five Benefits of Adding Us to Your Trusted Team"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-8 space-y-5",
									children: FIVE_BENEFITS.map((benefit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex size-6 shrink-0 items-center justify-center rounded-full bg-[#1b4e94] text-white",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 stroke-[3]" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base sm:text-lg font-medium text-slate-700",
											children: benefit
										})]
									}, benefit))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-5 flex justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative size-72 sm:size-84 overflow-hidden rounded-full border-4 border-[#3b82f6]/20 p-2 shadow-2xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "https://www.smgaba.com/wp-content/uploads/2021/11/home-feature-hospitality.jpg",
										alt: "SMG Partnership",
										className: "size-full rounded-full object-cover"
									})
								})
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-24 bg-[#0f2142] text-white relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto max-w-4xl px-6 lg:px-10 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Here's Why We're in your corner!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative my-12 px-4 sm:px-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto mb-8 flex size-24 items-center justify-center rounded-full bg-[#0a1730] border-2 border-white/20 text-white font-serif-hero text-xs font-bold uppercase tracking-wider p-2 shadow-xl",
										children: TESTIMONIALS[activeTestimonial].company
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-serif-hero text-xl sm:text-2xl md:text-3xl italic text-slate-100 leading-relaxed max-w-2xl mx-auto",
										children: [
											"\"",
											TESTIMONIALS[activeTestimonial].quote,
											"\""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 text-sm font-semibold text-blue-300",
										children: ["— ", TESTIMONIALS[activeTestimonial].author]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-center gap-2 mb-10",
								children: TESTIMONIALS.map((_, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setActiveTestimonial(idx),
									className: `size-2.5 rounded-full transition-all ${activeTestimonial === idx ? "w-7 bg-white" : "bg-white/30"}`,
									"aria-label": `Testimonial slide ${idx + 1}`
								}, idx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/testimonials",
								className: "inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0f2142] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
								children: "READ ALL TESTIMONIALS"
							}) })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact-form",
					className: "py-20 sm:py-28 bg-[#0b172e] text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center mb-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-white",
								children: "Let's Talk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm sm:text-base text-blue-200",
								children: "How We Can Help?"
							})]
						}), submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-blue-400/30 bg-blue-500/10 p-8 text-center backdrop-blur-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-12 text-blue-400" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-serif-hero text-2xl font-bold text-white",
									children: "Thank You!"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-blue-100",
									children: "Your message has been received. Our team will contact you shortly."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (e) => {
								e.preventDefault();
								setSubmitted(true);
							},
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Your Name *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									placeholder: "Company Name",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									required: true,
									placeholder: "Email or Phone Number *",
									className: "h-12 w-full rounded-xl border border-white/20 bg-white/10 px-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Best Time to Contact"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Morning",
											children: "Morning (8:30am – 12:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Afternoon",
											children: "Afternoon (12:00pm – 5:00pm)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Evening",
											children: "Evening (5:00pm – 7:00pm)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-wider text-blue-200/90 mb-1.5",
									children: "Services"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-12 w-full rounded-xl border border-white/20 bg-[#142340] px-4 text-sm text-white focus:border-white focus:outline-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Outsourced Bookkeeping",
											children: "Outsourced Bookkeeping"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "CFO on the Go",
											children: "CFO on the Go"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Tax Services",
											children: "Tax Services"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Back Office Management",
											children: "Back Office Management"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Hospitality Accounting",
											children: "Hospitality Accounting"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									placeholder: "Comments",
									className: "w-full rounded-xl border border-white/20 bg-white/10 p-4 text-sm text-white placeholder:text-white/60 focus:border-white focus:bg-white/15 focus:outline-none transition"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										id: "optin-check",
										required: true,
										className: "mt-1 size-4 rounded border-white/20 bg-white/10 text-blue-500 focus:ring-0"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "optin-check",
										className: "text-xs text-slate-300/90 leading-relaxed",
										children: "I agree to receive messages and updates from SMG Accounting & Advisory."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.7rem] text-slate-400/80 pt-1 leading-relaxed",
									children: "By submitting this form, you consent to our communication regarding your inquiry. Your information is kept strictly confidential."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-4 text-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "inline-flex items-center justify-center rounded-full bg-white px-12 py-3.5 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#0b172e] shadow-lg transition-all hover:bg-slate-100 hover:scale-105 active:scale-95",
										children: "SEND"
									})
								})
							]
						})]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { AboutUsPage as component };

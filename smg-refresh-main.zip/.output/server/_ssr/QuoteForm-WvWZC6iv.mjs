import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Check, d as ShieldCheck, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { i as cn, t as Button } from "./Footer-D47_iQ4w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/QuoteForm-WvWZC6iv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SERVICES = [
	"Outsourced Bookkeeping",
	"CFO on the Go",
	"Tax Services",
	"Back Office Management"
];
function QuoteForm() {
	const [selectedServices, setSelectedServices] = (0, import_react.useState)(["Outsourced Bookkeeping"]);
	const [optIn, setOptIn] = (0, import_react.useState)(true);
	const [sent, setSent] = (0, import_react.useState)(false);
	const toggleService = (s) => {
		setSelectedServices((prev) => prev.includes(s) ? prev.length > 1 ? prev.filter((item) => item !== s) : prev : [...prev, s]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-white py-20 lg:py-28",
		id: "get-a-quote",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
							children: "Get Started"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]",
							children: "Request a Custom Advisory Proposal"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-base leading-relaxed text-slate-600",
							children: "Schedule a 15-minute discovery call to discuss your financial workflows, software stack, and customized monthly pricing."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-7 shrink-0 items-center justify-center rounded-full bg-blue-50 text-xs font-bold text-blue-600",
										children: "1"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold text-slate-900",
										children: "15-Min Discovery Session"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-slate-500",
										children: "Understand your entities and immediate operational priorities."
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-7 shrink-0 items-center justify-center rounded-full bg-blue-50 text-xs font-bold text-blue-600",
										children: "2"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold text-slate-900",
										children: "Custom Scope & Fixed Pricing"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-slate-500",
										children: "Transparent monthly retainer with zero hidden hourly fees."
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start gap-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-7 shrink-0 items-center justify-center rounded-full bg-blue-50 text-xs font-bold text-blue-600",
										children: "3"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold text-slate-900",
										children: "Seamless Team Onboarding"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-slate-500",
										children: "Meet your dedicated CPA and bookkeeper who handle the rest."
									})] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex items-center gap-3 rounded-xl border border-slate-200/80 bg-slate-50 p-3.5 text-xs text-slate-600",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 shrink-0 text-blue-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "All consultations are confidential and protected by CPA ethics standards." })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-7",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "rounded-2xl border border-slate-200 bg-white p-7 shadow-sm sm:p-9",
						onSubmit: (e) => {
							e.preventDefault();
							setSent(true);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-semibold uppercase tracking-wider text-slate-700",
								children: "Services Needed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2.5 flex flex-wrap gap-2",
								children: SERVICES.map((s) => {
									const isSelected = selectedServices.includes(s);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => toggleService(s),
										className: cn("rounded-full px-3.5 py-1.5 text-xs font-medium transition-all", isSelected ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 text-slate-700 hover:bg-slate-200/70"),
										children: [isSelected && "✓ ", s]
									}, s);
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 grid gap-4 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "sm:col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "fullname",
											className: "block text-xs font-medium text-slate-700",
											children: "Full Name or Company"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "fullname",
											type: "text",
											required: true,
											placeholder: "Alex Morgan / Beacon Group LLC",
											className: "mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 placeholder:text-slate-400"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "phone",
										className: "block text-xs font-medium text-slate-700",
										children: "Phone Number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "phone",
										type: "tel",
										required: true,
										placeholder: "(631) 481-8600",
										className: "mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 placeholder:text-slate-400"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "email",
										className: "block text-xs font-medium text-slate-700",
										children: "Email Address"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "email",
										type: "email",
										required: true,
										placeholder: "alex@company.com",
										className: "mt-1.5 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10 placeholder:text-slate-400"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "best-time",
										className: "block text-xs font-medium text-slate-700",
										children: "Best Time to Call"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "best-time",
										defaultValue: "Anytime",
										className: "mt-1.5 h-11 w-full appearance-none rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Anytime" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Morning (9am - 12pm)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Afternoon (12pm - 4pm)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Evening (4pm - 6pm)" })
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "timezone",
										className: "block text-xs font-medium text-slate-700",
										children: "Timezone"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "timezone",
										defaultValue: "Eastern",
										className: "mt-1.5 h-11 w-full appearance-none rounded-xl border border-slate-200 bg-white px-3.5 text-sm text-slate-900 outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Eastern Time (ET)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Central Time (CT)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Mountain Time (MT)" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Pacific Time (PT)" })
										]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-start gap-2.5 rounded-xl bg-slate-50 p-3 text-left text-xs text-slate-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setOptIn((v) => !v),
									className: cn("mt-0.5 grid size-4 shrink-0 place-items-center rounded border transition-colors", optIn ? "border-blue-600 bg-blue-600 text-white" : "border-slate-300 bg-white"),
									children: optIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Opt in to receive automated consultation reminders from SMG. Message & data rates may apply." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex flex-col items-center justify-between gap-4 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "w-full sm:w-auto rounded-full bg-blue-600 px-7 font-bold text-white hover:bg-blue-500",
									children: "Request Consultation"
								}), sent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-semibold text-emerald-600",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inquiry received. We'll be in touch promptly." })]
								})]
							})
						]
					})
				})]
			})
		})
	});
}
//#endregion
export { QuoteForm as t };

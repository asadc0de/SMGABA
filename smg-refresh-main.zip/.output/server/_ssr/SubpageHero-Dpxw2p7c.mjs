import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function SubpageHero({ bgImage, title, description, buttonText, buttonHref = "#contact-form", eyebrow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate overflow-hidden bg-[#122344] pt-36 pb-20 sm:pt-44 sm:pb-28 lg:pt-52 lg:pb-32 text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: bgImage,
				alt: "",
				"aria-hidden": "true",
				className: "absolute inset-0 size-full object-cover object-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0",
				style: { background: `
            linear-gradient(105deg, rgba(16, 32, 64, 0.94) 0%, rgba(24, 48, 92, 0.88) 45%, rgba(30, 60, 115, 0.82) 100%)
          ` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-15 mix-blend-overlay pointer-events-none",
				style: {
					backgroundImage: `url('https://www.smgaba.com/wp-content/uploads/2021/11/smg-wallpaper.jpg')`,
					backgroundSize: "cover"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-6xl px-6 lg:px-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl text-left",
					children: [
						eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1 text-xs font-bold uppercase tracking-widest text-blue-200 backdrop-blur-md border border-white/15",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: eyebrow })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-serif-hero text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white drop-shadow-sm",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-base sm:text-lg leading-relaxed text-blue-50/95 font-normal",
							children: description
						}),
						buttonText && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: buttonHref,
								className: "inline-flex items-center justify-center rounded-full bg-white px-8 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider text-[#142340] shadow-lg transition-all duration-200 hover:bg-slate-100 hover:scale-105 active:scale-95",
								children: buttonText
							})
						})
					]
				})
			})
		]
	});
}
//#endregion
export { SubpageHero as t };

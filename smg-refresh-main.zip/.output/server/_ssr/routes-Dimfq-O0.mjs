import { n as __toESM } from "../_runtime.mjs";
import { i as performance_default } from "../_libs/h3-v2+rou3+srvx+unenv.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as ChevronRight, D as Compass, O as Clock, b as Layers, d as ShieldCheck, g as MapPin, i as Users, k as CircleCheck, m as Phone, o as TrendingUp, s as Star, t as Zap, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header, t as Button } from "./Footer-D47_iQ4w.mjs";
import { t as QuoteForm } from "./QuoteForm-WvWZC6iv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dimfq-O0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HERO_IMAGE = "https://www.smgaba.com/wp-content/uploads/2021/11/smg-wallpaper.jpg";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate flex min-h-[82vh] md:min-h-[86vh] items-center overflow-hidden bg-[#0a152b]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: HERO_IMAGE,
				alt: "SMG Accounting & Advisory Wallpaper",
				"aria-hidden": "true",
				className: "absolute inset-0 size-full object-cover object-center opacity-40 mix-blend-luminosity"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0",
				style: { background: `
            radial-gradient(ellipse at 80% 20%, rgba(59, 130, 246, 0.25) 0%, transparent 60%),
            linear-gradient(135deg, rgba(10, 21, 43, 0.96) 0%, rgba(15, 32, 67, 0.92) 50%, rgba(24, 52, 107, 0.85) 100%)
          ` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto w-full max-w-7xl px-5 pt-36 pb-20 sm:pt-40 sm:pb-24 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-2 rounded-full border border-blue-400/25 bg-blue-500/10 px-4 py-1.5 backdrop-blur-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex size-2 rounded-full bg-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold uppercase tracking-wider text-blue-200",
								children: "Full-Service Accounting, Bookkeeping & Advisory · NY & FL"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-6 text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl lg:text-[4rem] lg:leading-[1.12]",
							children: "Modern Financial Operations for Growing Businesses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-6 max-w-2xl text-base leading-relaxed text-blue-100/85 sm:text-lg",
							children: "Outsourced bookkeeping, fractional CFO leadership, and proactive tax strategy. Built for hospitality, real estate, and growth-oriented companies."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col items-center justify-center gap-3.5 sm:flex-row sm:gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/contact",
								className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-blue-600 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-blue-600/30 transition-all duration-200 hover:bg-blue-500 hover:scale-[1.02] sm:w-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Schedule a Consultation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/solutions",
								className: "inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-200 hover:bg-white/10 sm:w-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Explore Solutions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-blue-300" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-12 flex flex-wrap items-center justify-center gap-6 border-t border-white/10 pt-8 text-xs font-medium text-blue-200/80 sm:gap-10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "500+ Active Clients" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline text-white/20",
									children: "•"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "$500M+ Portfolio Advised" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline text-white/20",
									children: "•"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-blue-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inc. 5000 Honoree" })]
								})
							]
						})
					]
				})
			})
		]
	});
}
var STATS = [
	{
		prefix: "$",
		value: 500,
		suffix: "M+",
		label: "Assets & Revenue Advised",
		sub: "Comprehensive annual portfolio"
	},
	{
		prefix: "",
		value: 500,
		suffix: "+",
		label: "Active Business Clients",
		sub: "Hospitality, Real Estate & SMBs"
	},
	{
		prefix: "",
		value: 99,
		suffix: ".4%",
		label: "Client Retention Rate",
		sub: "Long-term trusted partnerships"
	},
	{
		prefix: "",
		value: 20,
		suffix: "+",
		label: "Years of Leadership",
		sub: "Senior CPAs & advisory team"
	}
];
function Counter({ prefix = "", value, suffix, active }) {
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		let raf = 0;
		const start = performance_default.now();
		const duration = 1600;
		const tick = (t) => {
			const p = Math.min((t - start) / duration, 1);
			const eased = 1 - Math.pow(1 - p, 3);
			setN(Math.round(value * eased));
			if (p < 1) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [active, value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "font-display text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl tabular-nums",
		children: [
			prefix,
			n,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-blue-600",
				children: suffix
			})
		]
	});
}
function Stats() {
	const ref = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => entries.forEach((e) => e.isIntersecting && setActive(true)), { threshold: .2 });
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		ref,
		className: "border-y border-slate-200/80 bg-white py-16 lg:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-4 lg:gap-0 lg:divide-x lg:divide-slate-200",
				children: STATS.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex flex-col ${idx === 0 ? "lg:pr-8" : idx === 3 ? "lg:pl-8" : "lg:px-8"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
							prefix: s.prefix,
							value: s.value,
							suffix: s.suffix,
							active
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-sm font-bold text-slate-900 sm:text-base",
							children: s.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-slate-500",
							children: s.sub
						})
					]
				}, s.label))
			})
		})
	});
}
var TESTIMONIALS = [
	{
		quote: "SMG has been our strategic accounting partner for over 5 years. Their team was instrumental in navigating challenging economic cycles and optimizing our cash flow.",
		author: "Leon U.",
		role: "Founder & Managing Director",
		company: "Hospitality & Restaurant Group"
	},
	{
		quote: "Professional, responsive, and attentive. They have been incredibly helpful with complicated multi-entity tax structures and routine monthly reporting.",
		author: "Andrew G.",
		role: "Managing Partner",
		company: "Commercial Real Estate"
	},
	{
		quote: "They have grown with me over 10 years from my first business to multiple enterprises. SMG comes up with creative solutions and provides peace of mind.",
		author: "Christopher T.",
		role: "President",
		company: "Multi-Entity Group"
	}
];
function Testimonials() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-[#fafbfc] py-20 lg:py-28",
		id: "testimonials",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-2xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
							children: "Customer Stories"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl",
							children: "Trusted by Founders & Operators Across NY & FL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-base text-slate-600",
							children: "Discover why growing businesses rely on SMG for bookkeeping, tax compliance, and CFO advisory."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-8 md:grid-cols-3",
					children: TESTIMONIALS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-7 shadow-[0_2px_10px_rgba(0,0,0,0.03)] transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-1 text-amber-400",
							children: [...Array(5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4 fill-amber-400 text-amber-400" }, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-sm leading-relaxed text-slate-700",
							children: [
								"\"",
								t.quote,
								"\""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex items-center gap-3 border-t border-slate-100 pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex size-10 items-center justify-center rounded-full bg-slate-100 font-bold text-xs text-slate-700",
								children: t.author.slice(0, 2).toUpperCase()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-slate-900",
								children: t.author
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-slate-500",
								children: [
									t.role,
									" · ",
									t.company
								]
							})] })]
						})]
					}, t.author))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "rounded-full px-6 font-semibold border-slate-300 text-slate-700 hover:bg-slate-50",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "/testimonials",
							children: ["Read All Client Stories ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1.5 size-4" })]
						})
					})
				})
			]
		})
	});
}
var LOGOS = [
	{
		src: "https://www.smgaba.com/wp-content/uploads/2023/09/SMG_Inc5000_1080x1080-03.png",
		alt: "Inc. 5000"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/1413842518-entrepreneur-logo.jpg",
		alt: "Entrepreneur Magazine"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/Stevie-Gold.jpg",
		alt: "Stevie Gold Award"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2021/11/2021-Exceptional-Workplace-Award-Logo-copy-1.png",
		alt: "Exceptional Workplace Award"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/LIBN_BPTW-Logo-NoYear.png",
		alt: "LIBN Best Places To Work"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/Hospitality-Restaurantowner.com-logo.png",
		alt: "RestaurantOwner.com"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2023/11/SPACC_ProudMemberLogo_Color.png",
		alt: "St. Pete Chamber of Commerce"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/Hospitality-NYC-Restaurant-Alliance.jpg",
		alt: "NYC Restaurant Alliance"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2021/11/nysra-rgb.png",
		alt: "NYSRA"
	},
	{
		src: "https://www.smgaba.com/wp-content/uploads/2020/01/HIA-logo.jpg",
		alt: "HIA-LI"
	}
];
function LogoMarquee() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-y border-slate-200/80 bg-slate-50/50 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-[0.7rem] font-bold uppercase tracking-[0.2em] text-slate-400",
				children: "Recognized by Leading Publications & Trade Associations"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mt-6 overflow-hidden",
			style: {
				maskImage: "linear-gradient(90deg, transparent, #000 15%, #000 85%, transparent)",
				WebkitMaskImage: "linear-gradient(90deg, transparent, #000 15%, #000 85%, transparent)"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "marquee-track flex w-max items-center gap-12 sm:gap-16",
				children: [...LOGOS, ...LOGOS].map((logo, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-12 w-32 items-center justify-center grayscale opacity-60 transition-all duration-200 hover:grayscale-0 hover:opacity-100 hover:scale-105",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo.src,
							alt: logo.alt,
							loading: "lazy",
							className: "max-h-9 max-w-full object-contain"
						})
					})
				}, `${logo.alt}-${i}`))
			})
		})]
	});
}
var SOLUTIONS = [
	{
		icon: Compass,
		tag: "Core Ledger",
		title: "Outsourced Bookkeeping",
		desc: "Daily transaction reconciliations, monthly closings, and real-time ledger management with zero backlog.",
		features: [
			"Daily Transaction Sync",
			"Month-End Financial Closes",
			"AP/AR & Vendor Invoicing"
		],
		href: "/solutions#outsourced-bookkeeping"
	},
	{
		icon: TrendingUp,
		tag: "Executive Strategy",
		title: "CFO on the Go",
		desc: "High-level strategic forecasting, cash flow modeling, and boardroom-ready financial reporting.",
		features: [
			"Cash Flow & Runway Modeling",
			"Custom KPI Dashboards",
			"Expansion & Growth Advisory"
		],
		href: "/solutions#cfo-on-the-go"
	},
	{
		icon: ShieldCheck,
		tag: "Compliance & Filing",
		title: "Tax Services",
		desc: "Proactive multi-state tax planning, corporate structuring, and seamless federal & state returns.",
		features: [
			"Federal & Multi-State Returns",
			"Proactive Tax Minimization",
			"Entity & 1031 Structuring"
		],
		href: "/solutions#tax-services"
	},
	{
		icon: Layers,
		tag: "Operations",
		title: "Back Office Management",
		desc: "Complete operational back office support including tipped payroll, POS integration, and vendor management.",
		features: [
			"Tipped Payroll Processing",
			"POS & Inventory System Sync",
			"Automated Bill.com Workflows"
		],
		href: "/solutions#back-office"
	}
];
var LOCATIONS = [
	{
		name: "Long Island Headquarters",
		city: "Islandia, NY",
		badge: "Headquarters",
		address: ["300 Corporate Plaza", "Islandia, NY 11749"],
		phone: "(631) 481-8600",
		fax: "(631) 481-8601",
		hours: "Mon – Fri: 8:30am – 5:30pm (Sat* 9am – 5pm)",
		href: "/islandia-location",
		mapsUrl: "https://maps.google.com/?q=300+Corporate+Plaza+Islandia+NY+11749"
	},
	{
		name: "Manhattan Office",
		city: "New York, NY",
		badge: "Flagship Metro",
		address: ["561 Seventh Avenue, 9th Floor", "New York, NY 10018"],
		phone: "(212) 203-4700",
		fax: "(631) 481-8601",
		hours: "Mon – Fri: 8:30am – 5:30pm (Sat* 9am – 5pm)",
		href: "/new-york-city-location",
		mapsUrl: "https://maps.google.com/?q=561+Seventh+Avenue+New+York+NY+10018"
	},
	{
		name: "Florida Regional Office",
		city: "St. Petersburg, FL",
		badge: "Southeast Hub",
		address: ["646 94th Ave N", "St. Petersburg, FL 33702"],
		phone: "(727) 388-3378",
		fax: "(727) 318-4096",
		hours: "Mon – Fri: 9:00am – 5:00pm",
		href: "/tierra-verde-fl",
		mapsUrl: "https://maps.google.com/?q=646+94th+Ave+N+St+Petersburg+FL+33702"
	}
];
function Index() {
	const [newsletterEmail, setNewsletterEmail] = (0, import_react.useState)("");
	const [subscribed, setSubscribed] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMarquee, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-white py-20 lg:py-28",
					id: "about",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto max-w-2xl text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
										children: "The SMG Advantage"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]",
										children: "Accounting & Advisory Built for Modern Operations"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base leading-relaxed text-slate-600 sm:text-lg",
										children: "No backward-looking reports delivered 30 days late. We provide real-time cloud visibility, weekly flash reporting, and proactive executive counsel."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-14 grid gap-8 md:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-slate-200/80 bg-[#fafbfc] p-8 shadow-sm transition-all hover:border-slate-300 hover:shadow-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex size-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-6" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-6 text-lg font-bold text-slate-900",
												children: "Strategic Growth Advisory"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-slate-600",
												children: "We don't just file your year-end taxes. We meet regularly to review cash flow runways, evaluate unit economics, and forecast expansion."
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-slate-200/80 bg-[#fafbfc] p-8 shadow-sm transition-all hover:border-slate-300 hover:shadow-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex size-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-6" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-6 text-lg font-bold text-slate-900",
												children: "Modern Cloud Stack"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-slate-600",
												children: "Direct integration with QuickBooks Online, Toast, Restaurant365, Bill.com, and Gusto. Access accurate, up-to-date numbers anytime."
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-slate-200/80 bg-[#fafbfc] p-8 shadow-sm transition-all hover:border-slate-300 hover:shadow-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex size-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-6 text-lg font-bold text-slate-900",
												children: "Dedicated CPA Team"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-slate-600",
												children: "You get an assigned senior bookkeeper and reviewing CPA who know your business, understand your industry, and respond rapidly."
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 flex justify-center gap-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									className: "rounded-full px-6 font-semibold border-slate-300 text-slate-700 hover:bg-slate-50",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "/about-us",
										children: "Learn More About Our Team →"
									})
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-[#fafbfc] py-20 lg:py-28",
					id: "solutions",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto max-w-2xl text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
										children: "Services & Capabilities"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]",
										children: "Everything You Need to Run Your Back Office"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base leading-relaxed text-slate-600",
										children: "From daily transaction reconciliations to executive CFO strategy, choose the exact level of support your business requires."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
								children: SOLUTIONS.map((s) => {
									const Icon = s.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-7 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-slate-300 hover:shadow-md",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex size-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[0.65rem] font-bold uppercase tracking-wider text-slate-400",
													children: s.tag
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-6 text-lg font-bold text-slate-900",
												children: s.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-xs leading-relaxed text-slate-600",
												children: s.desc
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
												className: "mt-5 space-y-2 border-t border-slate-100 pt-4 text-xs text-slate-700",
												children: s.features.map((feat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 shrink-0 text-blue-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: feat })]
												}, feat))
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-6 border-t border-slate-100 pt-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: s.href,
												className: "inline-flex items-center gap-1 text-xs font-bold text-blue-600 transition-colors hover:text-blue-700",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Learn more" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
											})
										})]
									}, s.title);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "rounded-full bg-blue-600 px-7 font-semibold text-white hover:bg-blue-500",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "/solutions",
										children: "View All Solutions & Pricing"
									})
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-white py-20 lg:py-28",
					id: "hospitality",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-16",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:col-span-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
										children: "Flagship Specialty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]",
										children: "Built Specifically for Restaurants & Hospitality"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base leading-relaxed text-slate-600",
										children: "We work with hundreds of restaurant groups, bars, and hospitality venues across NY and FL. We know prime cost management, tipped labor laws, and multi-unit reporting inside and out."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 grid gap-4 sm:grid-cols-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-200/80 bg-[#fafbfc] p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-slate-900",
													children: "Prime Cost Optimization"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs text-slate-600",
													children: "Actionable F&B and labor controls to stay under 55–60%."
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-200/80 bg-[#fafbfc] p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-slate-900",
													children: "Weekly Flash P&L Reports"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs text-slate-600",
													children: "Real-time margin visibility instead of waiting 30 days for month-end."
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-200/80 bg-[#fafbfc] p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-slate-900",
													children: "Tip Credit & 80/20 Compliance"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs text-slate-600",
													children: "Safeguard your business against complex wage-and-hour audits."
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border border-slate-200/80 bg-[#fafbfc] p-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-slate-900",
													children: "POS & 7shifts Integration"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-1 text-xs text-slate-600",
													children: "Direct sync with Toast, Restaurant365, Square, and TouchBistro."
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 flex flex-wrap items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-semibold text-slate-400 uppercase tracking-wider",
												children: "Members of:"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700",
												children: "NYC Hospitality Alliance"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700",
												children: "New York State Restaurant Association"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-8",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											className: "rounded-full bg-blue-600 px-6 font-semibold text-white hover:bg-blue-500",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "/hospitality",
												children: "Explore Hospitality Advisory →"
											})
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:col-span-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mx-auto max-w-md lg:max-w-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-hidden rounded-2xl border border-slate-200 shadow-lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "https://www.smgaba.com/wp-content/uploads/2020/02/szngsfqqjkih5cqdjdk-ja-e1635541793896.jpg",
											alt: "Hospitality Accounting Client",
											loading: "lazy",
											className: "aspect-4/3 w-full object-cover"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute -bottom-5 -left-5 rounded-xl border border-slate-200 bg-white p-4 shadow-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-2xl font-bold text-slate-900",
											children: "200+"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-slate-500 font-medium",
											children: "Hospitality Venues Advised"
										})]
									})]
								})
							})]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-[#fafbfc] py-20 lg:py-28",
					id: "locations",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto max-w-2xl text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold uppercase tracking-[0.2em] text-blue-600",
										children: "Offices"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl",
										children: "Physical Offices in NY & FL. Serving Nationwide."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base text-slate-600",
										children: "Visit our physical locations or schedule a video consultation from anywhere in the US."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-14 grid gap-6 md:grid-cols-3",
								children: LOCATIONS.map((loc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-7 shadow-sm transition-all hover:border-slate-300 hover:shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold uppercase tracking-wider text-blue-600",
												children: loc.city
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-slate-100 px-2.5 py-0.5 text-[0.65rem] font-semibold text-slate-600",
												children: loc.badge
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 text-lg font-bold text-slate-900",
											children: loc.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-5 space-y-2 text-xs text-slate-600",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: loc.address.join(", ") })]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4 shrink-0 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: `tel:${loc.phone.replace(/[^0-9]/g, "")}`,
														className: "font-semibold text-slate-900 hover:text-blue-600",
														children: loc.phone
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-0.5 size-4 shrink-0 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: loc.hours })]
												})
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 border-t border-slate-100 pt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: loc.mapsUrl,
											target: "_blank",
											rel: "noreferrer",
											className: "inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:underline",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Get Directions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
										})
									})]
								}, loc.name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 text-center text-xs text-slate-400",
								children: "*Extended Saturday hours available during tax season (January 1 – April 15)."
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-white py-16 lg:py-24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative overflow-hidden rounded-3xl bg-[#0a152b] px-8 py-14 text-center text-white shadow-xl sm:px-16 sm:py-20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 mx-auto max-w-2xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl",
										children: "Ready to Modernize Your Accounting?"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-base leading-relaxed text-blue-100/80 sm:text-lg",
										children: "Join hundreds of businesses that trust SMG for outsourced bookkeeping, CFO advisory, and tax strategy."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-8 flex flex-col items-center justify-center gap-3.5 sm:flex-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "/contact",
											className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-blue-600 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-blue-600/30 transition-all hover:bg-blue-500 sm:w-auto",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Schedule a Consultation" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "/solutions",
											className: "inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/20 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white transition-all hover:bg-white/20 sm:w-auto",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Explore Solutions" })
										})]
									})
								]
							})
						})
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { Index as component };

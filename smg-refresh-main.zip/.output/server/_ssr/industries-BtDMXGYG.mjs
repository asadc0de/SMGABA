import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { B as Activity, C as HardHat, I as Building2, M as Check, N as Car, T as Factory, f as Scale, l as ShoppingBag, r as Utensils, z as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as Footer, r as Header } from "./Footer-D47_iQ4w.mjs";
import { t as SubpageHero } from "./SubpageHero-Dpxw2p7c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/industries-BtDMXGYG.js
var import_jsx_runtime = require_jsx_runtime();
var ALL_INDUSTRIES = [
	{
		title: "Hospitality & Restaurants",
		slug: "/hospitality",
		desc: "Single dining concepts to high-volume multi-unit hospitality groups, bars, and catering. Weekly prime cost control and tipped payroll compliance.",
		icon: Utensils,
		badge: "Flagship Practice",
		highlights: [
			"Weekly Prime Cost Tracking",
			"FICA Tip Tax Credit",
			"Toast & POS Reconciliations"
		]
	},
	{
		title: "Real Estate & Development",
		slug: "/real-estate",
		desc: "Property portfolios, syndicators, and commercial developers. CAM reconciliations, 1031 exchanges, and multi-entity partnership returns.",
		icon: Building2,
		highlights: [
			"Property-Level P&Ls",
			"1031 Exchange Timelines",
			"Cost Segregation & Depreciation"
		]
	},
	{
		title: "Automotive & Dealerships",
		slug: "/automotive",
		desc: "Franchised auto dealerships, pre-owned lots, and collision centers. Floor plan interest audits, parts inventory, and warranty claims.",
		icon: Car,
		highlights: [
			"Floor Plan Reconciliations",
			"DMS & Parts Inventory",
			"Departmental P&L Breakdown"
		]
	},
	{
		title: "Healthcare & Medical Practices",
		slug: "/healthcare",
		desc: "Physician groups, dental practices, and surgical centers. Equitable physician compensation formulas, practice management sync, and tax planning.",
		icon: Activity,
		highlights: [
			"Physician Comp Modeling",
			"EHR Revenue Reconciliation",
			"HIPAA-Compliant Books"
		]
	},
	{
		title: "Legal Professionals & Law Firms",
		slug: "/legal-professionals",
		desc: "Boutique law firms, solo practitioners, and multi-partner legal practices. Strict IOLTA trust compliance, partner equity draws, and realization.",
		icon: Scale,
		highlights: [
			"Three-Way IOLTA Audits",
			"Partner Draw Schedules",
			"Clio & Practice Software Sync"
		]
	},
	{
		title: "Construction & Contractors",
		slug: "/construction",
		desc: "General contractors, commercial builders, and specialty trade subcontractors. Job costing, WIP schedules, AIA progress billing, and bonding advisory.",
		icon: HardHat,
		highlights: [
			"Job Costing & WIP Reports",
			"AIA Progress Billing G702",
			"Certified Payroll Compliance"
		]
	},
	{
		title: "Manufacturers & Distributors",
		slug: "/manufacturers",
		desc: "Industrial manufacturers, assemblers, and wholesale distributors. Bill of Materials (BOM) standard costing, supply chain cash flow, and R&D credits.",
		icon: Factory,
		highlights: [
			"BOM & Standard Costing",
			"R&D Tax Credits (Sec. 41)",
			"Inventory Cycle Counts"
		]
	},
	{
		title: "Retail & Omni-Channel Commerce",
		slug: "/retail",
		desc: "Retail store chains, specialty boutiques, and e-commerce brands. Daily POS sync, inventory turn analysis, and multi-state sales tax compliance.",
		icon: ShoppingBag,
		highlights: [
			"Multi-Store POS Sync",
			"Inventory Turnover (GMROI)",
			"Multi-State Sales Tax"
		]
	}
];
function IndustriesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-white text-[#1c2d42] font-sans antialiased selection:bg-blue-100 selection:text-blue-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubpageHero, {
				bgImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1920&q=80",
				eyebrow: "Industry Specializations",
				title: "Industries We Serve",
				description: "Generic accounting fails when applied to specialized businesses. At SMG, our dedicated pods have deep vertical expertise in the specific regulations, KPIs, and tax codes governing your industry."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-20 sm:py-28 bg-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-6 lg:px-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center mb-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif-hero text-3xl sm:text-4xl lg:text-5xl font-bold text-[#142340]",
							children: "Tailored Expertise Across 8 Core Sectors"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base text-slate-600 max-w-2xl mx-auto",
							children: "Explore our specialized accounting practices built for operational clarity and tax minimization."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-8 sm:grid-cols-2 lg:grid-cols-2",
						children: ALL_INDUSTRIES.map((ind) => {
							const Icon = ind.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col justify-between rounded-3xl border border-stone-200/80 bg-[#fdfdfd] p-8 sm:p-10 shadow-sm transition-all duration-300 hover:shadow-xl hover:border-blue-300 hover:-translate-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex size-14 items-center justify-center rounded-2xl bg-[#14284b] text-white shadow-md",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-7 stroke-[1.75]" })
										}), ind.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-blue-50 border border-blue-200 px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary",
											children: ind.badge
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-6 font-serif-hero text-2xl font-bold text-[#14284b]",
										children: ind.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm sm:text-base text-slate-600 leading-relaxed font-normal",
										children: ind.desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-6 pt-6 border-t border-stone-200/70",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-bold uppercase tracking-wider text-[#14284b] mb-3",
											children: "Key Practice Highlights:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "space-y-2",
											children: ind.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-center gap-2.5 text-xs sm:text-sm text-slate-700 font-medium",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex size-4 shrink-0 items-center justify-center rounded-full bg-[#1b4e94] text-white",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-2.5 stroke-[3]" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h })]
											}, h))
										})]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 pt-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: ind.slug,
										className: "inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#14284b] py-3 text-xs sm:text-sm font-bold uppercase tracking-wider text-white transition-all hover:bg-[#1f3a6a] hover:scale-[1.02]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Explore ", ind.title.split("&")[0].trim()] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								})]
							}, ind.title);
						})
					})]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { IndustriesPage as component };

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B5Sdo0si.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/__root.tsx",
		children: [
			"/",
			"/about-us",
			"/automotive",
			"/careers",
			"/construction",
			"/contact",
			"/healthcare",
			"/hospitality",
			"/industries",
			"/islandia-location",
			"/legal-professionals",
			"/manufacturers",
			"/new-york-city-location",
			"/our-team",
			"/real-estate",
			"/resources",
			"/retail",
			"/solutions",
			"/testimonials",
			"/tierra-verde-fl"
		],
		preloads: ["/assets/index-CmyYL7fY.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CmyYL7fY.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-pwKEbHeR.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/trending-up-DlrJRZHU.js",
			"/assets/users-CAGabovk.js"
		]
	},
	"/about-us": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/about-us.tsx",
		children: void 0,
		preloads: [
			"/assets/about-us-DlXILDTD.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/heart-BTufwW6M.js",
			"/assets/users-CAGabovk.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/automotive": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/automotive.tsx",
		children: void 0,
		preloads: [
			"/assets/automotive-D2ufgVLN.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/careers": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/careers.tsx",
		children: void 0,
		preloads: [
			"/assets/careers-CzbV-myN.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/heart-BTufwW6M.js",
			"/assets/trending-up-DlrJRZHU.js",
			"/assets/users-CAGabovk.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/construction": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/construction.tsx",
		children: void 0,
		preloads: [
			"/assets/construction-BP7WHDAF.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-uqvGLCUU.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/printer-CYRHvVKg.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/healthcare": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/healthcare.tsx",
		children: void 0,
		preloads: [
			"/assets/healthcare-Bo6CZ43L.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/hospitality": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/hospitality.tsx",
		children: void 0,
		preloads: [
			"/assets/hospitality-CGO6wN_k.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/industries": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/industries.tsx",
		children: void 0,
		preloads: [
			"/assets/industries-CfVe2pYc.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/islandia-location": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/islandia-location.tsx",
		children: void 0,
		preloads: [
			"/assets/islandia-location-Bx7eCkFF.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/printer-CYRHvVKg.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/legal-professionals": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/legal-professionals.tsx",
		children: void 0,
		preloads: [
			"/assets/legal-professionals-ufQecwLh.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/manufacturers": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/manufacturers.tsx",
		children: void 0,
		preloads: [
			"/assets/manufacturers-DKPkt65p.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/new-york-city-location": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/new-york-city-location.tsx",
		children: void 0,
		preloads: [
			"/assets/new-york-city-location-e4YGuwlY.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/printer-CYRHvVKg.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/our-team": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/our-team.tsx",
		children: void 0,
		preloads: [
			"/assets/our-team-YBInhNT7.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/real-estate": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/real-estate.tsx",
		children: void 0,
		preloads: [
			"/assets/real-estate-B76ObYEC.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/resources": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/resources.tsx",
		children: void 0,
		preloads: [
			"/assets/resources-BJC-16c1.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/retail": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/retail.tsx",
		children: void 0,
		preloads: [
			"/assets/retail-B2USX7ym.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/solutions": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/solutions.tsx",
		children: void 0,
		preloads: [
			"/assets/solutions-Bc_SMcD7.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/check-BoyMFbN9.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/testimonials": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/testimonials.tsx",
		children: void 0,
		preloads: [
			"/assets/testimonials--xd5hZ_Q.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/circle-check-m-xoSML6.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	},
	"/tierra-verde-fl": {
		filePath: "C:/Users/alihassan/Desktop/smg-refresh-main/smg-refresh-main/src/routes/tierra-verde-fl.tsx",
		children: void 0,
		preloads: [
			"/assets/tierra-verde-fl-BbRTZ86p.js",
			"/assets/Footer-DCuHzo4v.js",
			"/assets/clock-DVaOhTcZ.js",
			"/assets/printer-CYRHvVKg.js",
			"/assets/QuoteForm-BU-WVsHQ.js",
			"/assets/SubpageHero-BuygxZJr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

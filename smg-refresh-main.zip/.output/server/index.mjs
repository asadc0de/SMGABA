globalThis.__nitro_main__ = import.meta.url;
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx+unenv.mjs";
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"237f-9P9yfXGCXnP/VCw77AuvDAKg3AY\"",
		"mtime": "2026-08-29T15:10:46.000Z",
		"size": 9087,
		"path": "../public/favicon.svg"
	},
	"/smg-logo-white.svg": {
		"type": "image/svg+xml",
		"etag": "\"237f-wqYaFULuYzpZnfG7rfhP8TwUHwI\"",
		"mtime": "2026-08-29T15:10:46.000Z",
		"size": 9087,
		"path": "../public/smg-logo-white.svg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-29T15:10:46.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/smg-logo.svg": {
		"type": "image/svg+xml",
		"etag": "\"2382-SwIY/3Krz/bVtTiLQ4yJJPc3ZmY\"",
		"mtime": "2026-08-29T15:10:46.000Z",
		"size": 9090,
		"path": "../public/smg-logo.svg"
	},
	"/assets/about-us-DlXILDTD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"343e-gp+FoEpKbZXbpLPmysKSi7QdpaY\"",
		"mtime": "2026-08-30T07:39:34.890Z",
		"size": 13374,
		"path": "../public/assets/about-us-DlXILDTD.js"
	},
	"/assets/automotive-D2ufgVLN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e87-p8KYQiEbWP4u0DFGDo+th+C05+0\"",
		"mtime": "2026-08-30T07:39:34.891Z",
		"size": 7815,
		"path": "../public/assets/automotive-D2ufgVLN.js"
	},
	"/assets/careers-CzbV-myN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1746-v0D2qdKuaWjfq8GQXy8i5fmqu98\"",
		"mtime": "2026-08-30T07:39:34.895Z",
		"size": 5958,
		"path": "../public/assets/careers-CzbV-myN.js"
	},
	"/assets/check-BoyMFbN9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"72-m24ovjAEvjL8cIHTWAQZa9U7wj4\"",
		"mtime": "2026-08-30T07:39:34.895Z",
		"size": 114,
		"path": "../public/assets/check-BoyMFbN9.js"
	},
	"/assets/circle-check-m-xoSML6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a8-+6jYD4JvUmrxt+KPm/zPt+f+wGs\"",
		"mtime": "2026-08-30T07:39:34.899Z",
		"size": 168,
		"path": "../public/assets/circle-check-m-xoSML6.js"
	},
	"/assets/clock-DVaOhTcZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-gPJerZiz4qjamKIviHAkHXidkRo\"",
		"mtime": "2026-08-30T07:39:34.901Z",
		"size": 159,
		"path": "../public/assets/clock-DVaOhTcZ.js"
	},
	"/assets/construction-BP7WHDAF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1efa-JKhdE1rVGcI7Y9TCacv+x1uAEO4\"",
		"mtime": "2026-08-30T07:39:34.914Z",
		"size": 7930,
		"path": "../public/assets/construction-BP7WHDAF.js"
	},
	"/assets/contact-uqvGLCUU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d6a-8qDFRGfJ+iGcTinLmSxh+amwVq4\"",
		"mtime": "2026-08-30T07:39:34.920Z",
		"size": 3434,
		"path": "../public/assets/contact-uqvGLCUU.js"
	},
	"/assets/Footer-DCuHzo4v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11b28-QhS6BYj+OK5ku74dfropRTgHcG8\"",
		"mtime": "2026-08-30T07:39:34.885Z",
		"size": 72488,
		"path": "../public/assets/Footer-DCuHzo4v.js"
	},
	"/assets/healthcare-Bo6CZ43L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f27-6D1D4ePujfHiQ5MGtOK0GeOqPvs\"",
		"mtime": "2026-08-30T07:39:34.920Z",
		"size": 7975,
		"path": "../public/assets/healthcare-Bo6CZ43L.js"
	},
	"/assets/heart-BTufwW6M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f8-WH0iZB5CNG7GhBc6ZJuM/4/XJyU\"",
		"mtime": "2026-08-30T07:39:34.932Z",
		"size": 248,
		"path": "../public/assets/heart-BTufwW6M.js"
	},
	"/assets/hospitality-CGO6wN_k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"222c-5h6gCEVSu3covQIH7r/FiBGuSZo\"",
		"mtime": "2026-08-30T07:39:34.951Z",
		"size": 8748,
		"path": "../public/assets/hospitality-CGO6wN_k.js"
	},
	"/assets/index-CmyYL7fY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57336-PXBxkermAO8wjx62GGJvIPEa9lU\"",
		"mtime": "2026-08-30T07:39:34.884Z",
		"size": 357174,
		"path": "../public/assets/index-CmyYL7fY.js"
	},
	"/assets/industries-CfVe2pYc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1763-bpL78BeX99TzqBEaCU5SSaZrg3E\"",
		"mtime": "2026-08-30T07:39:34.963Z",
		"size": 5987,
		"path": "../public/assets/industries-CfVe2pYc.js"
	},
	"/assets/islandia-location-Bx7eCkFF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1047-701Q13q9pU1BSw685SwdsN8xOjU\"",
		"mtime": "2026-08-30T07:39:34.974Z",
		"size": 4167,
		"path": "../public/assets/islandia-location-Bx7eCkFF.js"
	},
	"/assets/legal-professionals-ufQecwLh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1eb8-hLJfPXb7pfOYSwm5V8Jua1OZVZI\"",
		"mtime": "2026-08-30T07:39:34.992Z",
		"size": 7864,
		"path": "../public/assets/legal-professionals-ufQecwLh.js"
	},
	"/assets/manufacturers-DKPkt65p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ef5-qg0c2zU8wooKtm5eBI2L+NElzqo\"",
		"mtime": "2026-08-30T07:39:34.999Z",
		"size": 7925,
		"path": "../public/assets/manufacturers-DKPkt65p.js"
	},
	"/assets/new-york-city-location-e4YGuwlY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1050-XnqFpPshVY2r+ypHCM3vHPQneQ8\"",
		"mtime": "2026-08-30T07:39:35.029Z",
		"size": 4176,
		"path": "../public/assets/new-york-city-location-e4YGuwlY.js"
	},
	"/assets/our-team-YBInhNT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f91-Q4prGU1ghY3Q8i1k9ZK1uROcUww\"",
		"mtime": "2026-08-30T07:39:35.040Z",
		"size": 3985,
		"path": "../public/assets/our-team-YBInhNT7.js"
	},
	"/assets/printer-CYRHvVKg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135-gxu8sqJzhyu06A4jIPM1Mm0cUX8\"",
		"mtime": "2026-08-30T07:39:35.051Z",
		"size": 309,
		"path": "../public/assets/printer-CYRHvVKg.js"
	},
	"/assets/QuoteForm-BU-WVsHQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e90-JR1BCqKphXyYXJ3UyJt8zAWtDg4\"",
		"mtime": "2026-08-30T07:39:34.886Z",
		"size": 7824,
		"path": "../public/assets/QuoteForm-BU-WVsHQ.js"
	},
	"/assets/real-estate-B76ObYEC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f2f-JuZaR/mbNjkPnv9XtXEXdTJHEHw\"",
		"mtime": "2026-08-30T07:39:35.052Z",
		"size": 7983,
		"path": "../public/assets/real-estate-B76ObYEC.js"
	},
	"/assets/resources-BJC-16c1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13a5-4ZpxJZWZf3dEShbmNBe8cUHCf4c\"",
		"mtime": "2026-08-30T07:39:35.054Z",
		"size": 5029,
		"path": "../public/assets/resources-BJC-16c1.js"
	},
	"/assets/retail-B2USX7ym.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ef3-/L5F0XhpVyXHBu7T5/ogwe0GhWQ\"",
		"mtime": "2026-08-30T07:39:35.056Z",
		"size": 7923,
		"path": "../public/assets/retail-B2USX7ym.js"
	},
	"/assets/routes-pwKEbHeR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"699c-34SWv/6o7GFEuZ5CM3+mufZsQJQ\"",
		"mtime": "2026-08-30T07:39:35.058Z",
		"size": 27036,
		"path": "../public/assets/routes-pwKEbHeR.js"
	},
	"/assets/solutions-Bc_SMcD7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a38-KH2pcbi0ArEFCB1xXPwB4mbrdE8\"",
		"mtime": "2026-08-30T07:39:35.063Z",
		"size": 10808,
		"path": "../public/assets/solutions-Bc_SMcD7.js"
	},
	"/assets/styles-DjjGGLkd.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1c7c5-XlcNq4MpiNiZyl+XvFT/BqwjBgc\"",
		"mtime": "2026-08-30T07:39:35.075Z",
		"size": 116677,
		"path": "../public/assets/styles-DjjGGLkd.css"
	},
	"/assets/SubpageHero-BuygxZJr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"72a-FAmtff7ufSxr8cpvlOG9zoYj+CI\"",
		"mtime": "2026-08-30T07:39:34.887Z",
		"size": 1834,
		"path": "../public/assets/SubpageHero-BuygxZJr.js"
	},
	"/assets/testimonials--xd5hZ_Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b50-lfiofkbSs7oyQIDAFyi89GmuhjM\"",
		"mtime": "2026-08-30T07:39:35.067Z",
		"size": 15184,
		"path": "../public/assets/testimonials--xd5hZ_Q.js"
	},
	"/assets/tierra-verde-fl-BbRTZ86p.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f65-ChVuF/olz0076VxKyyM+sUdEA4c\"",
		"mtime": "2026-08-30T07:39:35.071Z",
		"size": 3941,
		"path": "../public/assets/tierra-verde-fl-BbRTZ86p.js"
	},
	"/assets/trending-up-DlrJRZHU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-bP/tOyM8BppBtfJOMdjCO4DLeUk\"",
		"mtime": "2026-08-30T07:39:35.072Z",
		"size": 165,
		"path": "../public/assets/trending-up-DlrJRZHU.js"
	},
	"/assets/users-CAGabovk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"128-rkBvDrqV42ViQA1UnC1BW2xqDEw\"",
		"mtime": "2026-08-30T07:39:35.072Z",
		"size": 296,
		"path": "../public/assets/users-CAGabovk.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_4siMqG = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_4siMqG
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
